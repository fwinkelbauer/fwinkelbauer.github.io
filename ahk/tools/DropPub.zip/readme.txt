DropPub.exe v1.2 (22.09.2010) by fwinkelbauer (www.florianwinkelbauer.com)
AutoHotkey v.1.0.48.05

License? Steal it. Now.

Icon by NIXUS Icon Pack (http://www.tutorial9.net/resources/nixus-icon-pack-60-beautiful-premium-icons-free/)