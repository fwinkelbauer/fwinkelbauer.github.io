12Clip.exe v1.6 (30.07.2011) by fwinkelbauer (www.florianwinkelbauer.com)
AutoHotkey v1.1.00.01

License? Steal it. Now.

[F1-F4] + c   copies selected content or current clipboard if there is no selection (Note: current clipboard will remain the same)
[F1-F4] + a   appends selected content (or current clipboard if there is no selection) to a clipboard variable (Note: files will be transformed into their absolute paths)
[F1-F4] + s   swaps the current clipboard with a clipboard variable
[F1-F4] + p   outputs the content in a tooltip (Note: files will be displayed through their absolute path)
[F1-F4] + v   pastes the content
[F1-F4] + b   pastes the content (if text) or the absolute path (if file)
[F1-F4] + d   clear clipboard
F1 + F2       show log (or use tray menu)
F3 + F4       set delimiter for append function (or use tray menu). To use tab, space, or enter as a delimiter, declare them as {tab}, {space} or {enter}

Icon by NIXUS Icon Pack (http://www.tutorial9.net/resources/nixus-icon-pack-60-beautiful-premium-icons-free/)